package kodlama.io.rentACar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentACarProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentACarProjectApplication.class, args);
	}

}
